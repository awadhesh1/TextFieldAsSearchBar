//
//  AppDelegate.h
//  TextFieldAsSearchBar
//
//  Created by Kumar on 12/05/16.
//  Copyright © 2016 Kumar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

